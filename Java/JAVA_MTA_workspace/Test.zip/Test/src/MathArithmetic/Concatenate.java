package MathArithmetic;

public class Concatenate {

	public static void main(String[] args) {
		String str1 = "Java ";
		String str2 = "Operators";
		int i = 1;
		double d = 1.2;
		String str3 = str1 + i + d;
		System.out.println(str1.concat(str2));
		System.out.println(str3);
	}

}
