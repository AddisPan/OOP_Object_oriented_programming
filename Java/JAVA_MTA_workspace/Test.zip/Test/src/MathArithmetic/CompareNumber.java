package MathArithmetic;

import java.util.Scanner;

public class CompareNumber {
	public static void main(String[] args) {
		System.out.println("Please key number1");
		Scanner n1 = new Scanner(System.in);
		double a = n1.nextDouble();

		System.out.println("Please key number2");
		Scanner n2 = new Scanner(System.in);
		double b = n2.nextDouble();

		System.out.println("Please key number3");
		Scanner n3 = new Scanner(System.in);
		double c = n1.nextDouble();

		double max, min;
		
//		if (a > b && a > c) {
//			if (b > c) {
//				max = a;
//				min = c;
//				System.out.println("Max=" + max + " Min=" + min);
//			} else {
//				max = a;
//				min = b;
//				System.out.println("Max=" + max + " Min=" + min);
//			}
//		}
//
//		if (b > a && b > c) {
//			if (a > c) {
//				max = b;
//				min = c;
//				System.out.println("Max=" + max + " Min=" + min);
//			} else {
//				max = b;
//				min = a;
//				System.out.println("Max=" + max + " Min=" + min);
//			}
//		}
//
//		if (c > a && c > b) {
//			if (a > b) {
//				max = c;
//				min = b;
//				System.out.println("Max=" + max + " Min=" + min);
//			} else {
//				max = c;
//				min = a;
//				System.out.println("Max=" + max + " Min=" + min);
//			}
//		}
	}
}
