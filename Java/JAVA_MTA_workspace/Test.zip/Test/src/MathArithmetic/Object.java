package MathArithmetic;

import java.util.Scanner;

class Student{
	String name;
	int number;
	
	int luckynumber = (int) (Math.random() * 99 + 1);
	
	Student(String n, int nm, int l){
		name = n;
		number = nm;
		luckynumber = l;
	}
	void show() {
		System.out.println("�P�ǦW�r�G" + name);
		System.out.println("�P�Ǯy���G" + number);
		System.out.println("���B���X�G" + luckynumber);
	}
}

public class Object {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		Student[] s1 = new Student[n];
		s1 [0] = new Student("���p��", 46, 6);
		s1 [1] = new Student("���j��", 26, 23);
		for (Student s11 : s1)
			s11.show();
	}

}
