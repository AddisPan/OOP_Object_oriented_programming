package MathArithmetic;

public class Area {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		final double  PI =3.1416;
		double r,Area;
		r = 10.8;
		Area = PI*r*r;
		System.out.println("Area of circle is:" + Area);
	}

}
