# -*- coding: utf-8 -*-
"""
Created on Thu Nov  7 13:35:00 2019

@author: Addis
"""
NUM_CHOICE =122

import A108222040_turtle
import A108222040_expression


def makeChoice():
    print("1:BMI")
    print("2:rectangle")
    print("3:Olypicas")
    print("4:drawpicture")
    print("5:A108222040_drawPolygon")
    print("6:A108222040_drawCircle")
    print("7:A108222040_drawStar")
    
    
    try:
        choice = int(input("what is your choice -->"))
    except:
        choice = NUM_CHOICE 
    return choice 
    

###
    
choice = makeChoice()
while(choice >= 1 and choice <= NUM_CHOICE):
    if(choice == 1):
        A108222040_expression.BMI()
    elif(choice == 2):
        A108222040_turtle.rectangle()
            
    elif(choice == 3):
        A108222040_turtle.Olypicas()
            
    elif(choice == 4):
        A108222040_turtle.drawpicture()
            
    elif(choice == 5):
        A108222040_turtle.A108222040_drawPolygon()
            
    elif(choice == 6):
        A108222040_turtle.A108222040_drawCircle()
            
    elif(choice == 7):
        A108222040_turtle.A108222040_drawStar()
            
    print("\n")
    choice = makeChoice()