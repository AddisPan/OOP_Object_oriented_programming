# -*- coding: utf-8 -*-
"""
Created on Thu Nov  7 13:52:30 2019

@author: Addis
"""

def rectangle():
    import turtle   
    turtle.pencolor('green')    
    turtle.forward(100)
    turtle.right(90)
    turtle.forward(50)
    turtle.right(90)
    turtle.forward(100)
    turtle.right(90)
    turtle.forward(50)
    

    turtle.pencolor('red')
    turtle.penup()
    turtle.goto(-100,50)
    turtle.pendown()
    turtle.right(90)
    turtle.forward(100)
    turtle.right(90)
    turtle.forward(50)
    turtle.right(90)
    turtle.forward(100)
    turtle.right(90)
    turtle.forward(50)

    turtle.pencolor('blue')
    turtle.penup()
    turtle.goto(-50,0)
    turtle.pendown()
    turtle.right(90)
    turtle.forward(100)
    turtle.right(90)
    turtle.forward(50)
    turtle.right(90)
    turtle.forward(100)
    turtle.right(90)
    turtle.forward(50)

    turtle.pencolor('black')
    turtle.penup()
    turtle.goto(-150,100)
    turtle.pendown()
    turtle.right(90)
    turtle.forward(200)
    turtle.right(90)
    turtle.forward(150)
    turtle.right(90)
    turtle.forward(200)
    turtle.right(90)
    turtle.forward(150)

def Olypicas():
    import turtle
    turtle.pencolor('black')
    turtle.pensize(5)
    turtle.circle(36)
    
    turtle.penup()
    turtle.goto(-80,0)
    turtle.pendown()
    turtle.pencolor('blue')
    turtle.circle(36)
    
    turtle.penup()
    turtle.goto(80,0)
    turtle.pendown()
    turtle.pencolor('red')
    turtle.circle(36)
    
    turtle.penup()
    turtle.goto(50,-30)
    turtle.pendown()
    turtle.pencolor('green')
    turtle.circle(36)
    
    turtle.penup()
    turtle.goto(-50,-30)
    turtle.pendown()
    turtle.pencolor('yellow')
    turtle.circle(36)
    
    turtle.pencolor('black')
    turtle.penup()
    turtle.goto(0,-70)
    turtle.pendown()
    turtle.write('A108222040_潘凌徵')
    
def drawpicture():    
    import turtle
    turtle.pencolor("green")
    turtle.pensize(6)
    for x in range(4):
        turtle.forward(100)
        turtle.right(90)
    turtle.penup()
    turtle.goto(-100,100)
    turtle.pendown()
    turtle.write("A108222040_潘凌徵")
    
    import turtle
    turtle.pencolor("red")
    turtle.pensize(5)
    for x in range(6):
        turtle.forward(100)
        turtle.right(60)
    turtle.penup()
    turtle.goto(-100,100)
    turtle.pendown()
    turtle.write("A108222040_潘凌徵")
    
    import turtle
    turtle.pencolor("blue")
    turtle.pensize(4)
    for x in range(8):
        turtle.forward(100)
        turtle.right(45)
    turtle.penup()
    turtle.goto(-100,100)
    turtle.pendown()
    turtle.write("A108222040_潘凌徵")
    
    
    import turtle
    NUM_CIRCLES = 36
    RADIUS = 100
    ANGLE = 10
    for x in range(NUM_CIRCLES):
        turtle.circle(RADIUS)
        turtle.left(ANGLE)
    
    import turtle
    NUM_CIRCLES = 72
    RADIUS = 100
    ANGLE = 5
    for x in range(NUM_CIRCLES):
        turtle.circle(RADIUS)
        turtle.left(ANGLE)
        

def A108222040_drawPolygon(color,angle,numLine,startX,startY,length):
    import turtle
    turtle.speed(500)
    turtle.penup()
    turtle.goto(startX,startY)
    turtle.setheading(0)
    turtle.pendown()
    turtle.pencolor(color)
    for x in range(numLine):
        turtle.forward(length)
        turtle.right(angle)

def A108222040_drawCircle(color,NUM_CIRCLES,RADIUS,ANGLE,startX,startY):
    import turtle
    turtle.speed(500)       
    turtle.penup()
    turtle.goto(startX,startY)
    turtle.setheading(0)
    turtle.pendown()
    turtle.pencolor(color)
    for x in range(NUM_CIRCLES):
        turtle.circle(RADIUS)
        turtle.left(ANGLE)

def A108222040_drawStar(color,NUM_LINES,LINE_LENGTH,ANGLE,startX,startY):
    import turtle
    turtle.speed(500)
    turtle.penup()
    turtle.goto(startX,startY)
    turtle.setheading(0)
    turtle.pendown()
    turtle.pencolor(color)
    for x in range(NUM_LINES):
        turtle.forward(LINE_LENGTH)
        turtle.left(ANGLE)
     