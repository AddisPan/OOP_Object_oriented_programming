A108222040
潘凌徵
2019/10/17

import turtle
turtle.pencolor("green")
turtle.pensize(6)
for x in range(4):
    turtle.forward(100)
    turtle.right(90)
turtle.penup()
turtle.goto(-100,100)
turtle.pendown()
turtle.write("A108222040_潘凌徵")

import turtle
turtle.pencolor("red")
turtle.pensize(5)
for x in range(6):
    turtle.forward(100)
    turtle.right(60)
turtle.penup()
turtle.goto(-100,100)
turtle.pendown()
turtle.write("A108222040_潘凌徵")

import turtle
turtle.pencolor("blue")
turtle.pensize(4)
for x in range(8):
    turtle.forward(100)
    turtle.right(45)
turtle.penup()
turtle.goto(-100,100)
turtle.pendown()
turtle.write("A108222040_潘凌徵")


import turtle
NUM_CIRCLES = 36
RADIUS = 100
ANGLE = 10
for x in range(NUM_CIRCLES):
    turtle.circle(RADIUS)
    turtle.left(ANGLE)

import turtle
NUM_CIRCLES = 72
RADIUS = 100
ANGLE = 5
for x in range(NUM_CIRCLES):
    turtle.circle(RADIUS)
    turtle.left(ANGLE)
